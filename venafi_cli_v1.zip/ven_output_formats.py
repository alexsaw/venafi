log_data_format = {
	"activityName": {
			"selector": "activityName",
			"format": [28, "Activity Name"]
		},
	"activityType": {
			"selector": "activityType",
			"format": [18, "Activity Type"]
		},
	"message": {
			"selector": "message",
			"format": [138, "Message"]
		},
	"activityDate": {
			"selector": "activityDate",
			"format": [24, "Activity Date"],
			"specialFormatting": -6
		},
	"clientIpAddress": {
			"subsection": "payload",
			"selector": "clientIpAddress",
			"format": [16, "Client"]
		},
	"username": {
			"subsection": "payload",
			"selector": "username",
			"format": [20, "Username"],
			"specialFormatting": -11
		},
	"criticality": {
			"subsection": "payload",
			"selector": "criticality",
			"format": [12, "Criticality"]
		}
}

cert_data_format = {
	"subjectCN": {
			"selector": "subjectCN",
			"format": [40, "Subject Common Name"],
			"selectItem": 0
		},
	"fingerprint": {
			"selector": "fingerprint",
			"format": [41, "Fingerprint"]
		},
	"validityEnd": {
			"selector": "validityEnd",
			"format": [24, "Validity End Date"],
			"specialFormatting": -6
		},
	"id": {
			"selector": "id",
			"format": [37, "Venafi UUID"]
		},
	"certificateStatus": {
			"selector": "certificateStatus",
			"format": [8, "Status"]
		},
	"encryptionType": {
			"selector": "encryptionType",
			"format": [10, "Encryption"]
		},
	"subjectL": {
			"selector": "subjectL",
			"format": [16, "Locality"]
		},
	"subjectOU": {
			"selector": "subjectOU",
			"format": [12, "Org Unit"],
			"selectItem": 0
		},
	"issuerCN": {
			"selector": "issuerCN",
			"format": [25, "Issuer Common Name"],
			"selectItem": 0
		}
}